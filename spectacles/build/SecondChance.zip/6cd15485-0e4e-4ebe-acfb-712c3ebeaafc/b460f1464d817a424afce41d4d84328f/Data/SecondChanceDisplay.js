// SECOND CHANCE — adult Hands-Only CPR practice on Spectacles.
// One Text component owns the entire card so its lines cannot overlap.
// A pinch advances one screen. No CPR measurement or emergency call occurs.

var steps = ["check", "call", "hands", "compress", "aed"];
var titles = [
    "01 / CHECK RESPONSE",
    "02 / CALL 911 + AED",
    "03 / PLACE HANDS",
    "04 / PUSH HARD + FAST",
    "05 / USE AED"
];
var instructions = [
    ["Scene safe. Tap shoulders.", "Shout; check breathing.", "Gasping is not normal."],
    ["Call 911. Send someone", "for an AED. Follow", "dispatcher instructions."],
    ["Heel on chest center.", "Other hand on top.", "Shoulders over hands."],
    ["100-120 compressions/min.", "Let the chest rise fully.", "110 BPM practice beat."],
    ["Turn on AED. Follow", "its prompts. Resume CPR", "when prompted."]
];
var cues = [
    "Unresponsive + gasping?",
    "No call is placed here.",
    "Keep both arms straight.",
    "2 in / 5 cm; avoid over\n2.4 in / 6 cm.",
    "AED prompts guide you."
];

function drawing(kind, phase) {
    if (kind === "check") { return ["      O", "   o [ + ] o"]; }
    if (kind === "call") {
        return phase ? ["   [O AED]", "   GET AED"] : ["    [ 911 ]", "    CALL NOW"];
    }
    if (kind === "hands") { return ["      O", "    [ + ]", "    ===="]; }
    if (kind === "compress") {
        return phase ? ["      O", "    [ + ]", "     v", "    ===="] :
            ["      O", "    [ + ]", "     |", "    ===="];
    }
    return ["   [O AED]", "   [ ]  [ ]", "     > CPR"];
}

try {
    var obj = global.scene.createSceneObject("SC Single Practice Card");
    obj.getTransform().setWorldPosition(new vec3(0, 0, 0));
    var card = obj.createComponent("Component.Text");
    card.size = 68;
    card.depthTest = false;
    card.textFill.color = new vec4(1, 1, 1, 1);
    card.backgroundSettings.enabled = true;
    card.backgroundSettings.fill.color = new vec4(0.02, 0.07, 0.10, 0.9);
    card.backgroundSettings.cornerRadius = 0.16;
    card.backgroundSettings.margins.left = 1.2;
    card.backgroundSettings.margins.right = 1.2;
    card.backgroundSettings.margins.top = 0.8;
    card.backgroundSettings.margins.bottom = 0.8;

    var stepIndex = 0;
    var transitionAt = -1;
    var lastPinch = -1;
    var revealAt = -1;
    var phase = false;

    function progress() {
        var result = "";
        for (var i = 0; i < steps.length; i++) {
            result += i <= stepIndex ? "=" : "-";
        }
        return "[" + result + "]";
    }
    function render() {
        var kind = steps[stepIndex];
        var lines = ["ADULT CPR SIMULATION", "WITNESSED SUDDEN COLLAPSE", titles[stepIndex], ""];
        lines = lines.concat(drawing(kind, phase));
        lines.push("");
        lines = lines.concat(instructions[stepIndex]);
        lines.push(cues[stepIndex]);
        lines.push(progress() + "  " + (stepIndex === 4 ? "PINCH / RESTART" : "PINCH / SAY NEXT"));
        card.text = lines.join("\n");
    }
    function showStep() {
        phase = false;
        revealAt = steps[stepIndex] === "call" ? getTime() + 0.7 : -1;
        transitionAt = getTime();
        render();
        print("SECOND CHANCE practice step " + (stepIndex + 1) + "/5 " + steps[stepIndex]);
    }
    function update() {
        var now = getTime();
        var fade = Math.min(1, Math.max(0.3, (now - transitionAt) / 0.18));
        card.textFill.color = new vec4(1, 1, 1, fade);
        card.backgroundSettings.fill.color = new vec4(0.02, 0.07, 0.10, 0.9 * fade);
        if (steps[stepIndex] === "call" && !phase && now >= revealAt) {
            phase = true;
            render();
        }
        if (steps[stepIndex] !== "compress") { return; }
        var beat = (now % (60 / 110)) < 0.16;
        if (beat !== phase) {
            phase = beat;
            render();
        }
    }
    function advanceStep() {
        var now = getTime();
        if (now - lastPinch < 0.45) { return; }
        lastPinch = now;
        stepIndex = (stepIndex + 1) % steps.length;
        showStep();
    }
    function restartLesson() {
        var now = getTime();
        if (now - lastPinch < 0.45) { return; }
        lastPinch = now;
        stepIndex = 0;
        showStep();
    }
    function onVoiceText(eventArgs) {
        if (!eventArgs.isFinal) { return; }
        var command = eventArgs.text.toLowerCase().replace(/[\s.,!?，。！？]/g, "");
        if (/^(next|continue|下一步|继续)$/.test(command)) {
            advanceStep();
        } else if (/^(restart|startover|重来|重新开始)$/.test(command)) {
            restartLesson();
        }
    }

    showStep();
    script.createEvent("UpdateEvent").bind(update);
    script.createEvent("TriggerPrimaryEvent").bind(advanceStep);
    try {
        var gestures = require("LensStudio:GestureModule");
        gestures.getPinchDownEvent(0).add(advanceStep);
        gestures.getPinchDownEvent(1).add(advanceStep);
        print("SECOND CHANCE pinch controls ready");
    } catch (gestureError) {
        print("SECOND CHANCE pinch controls unavailable: " + gestureError);
    }
    try {
        var asr = require("LensStudio:AsrModule");
        var options = AsrModule.AsrTranscriptionOptions.create();
        options.silenceUntilTerminationMs = 650;
        options.mode = AsrModule.AsrMode.Balanced;
        options.onTranscriptionUpdateEvent.add(onVoiceText);
        options.onTranscriptionErrorEvent.add(function (errorCode) {
            print("SECOND CHANCE voice unavailable, code " + errorCode);
        });
        asr.startTranscribing(options);
        print("SECOND CHANCE voice session started");
    } catch (voiceError) {
        print("SECOND CHANCE voice unavailable: " + voiceError);
    }
} catch (error) {
    print("SECOND CHANCE setup failed: " + error);
}
