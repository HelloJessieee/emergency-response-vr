"use strict";
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FirstAidFinder = void 0;
var __selfType = requireType("./FirstAidFinder");
function component(target) {
    target.getTypeName = function () { return __selfType; };
    if (target.prototype.hasOwnProperty("getTypeName"))
        return;
    Object.defineProperty(target.prototype, "getTypeName", {
        value: function () { return __selfType; },
        configurable: true,
        writable: true
    });
}
let FirstAidFinder = (() => {
    let _classDecorators = [component];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = BaseScriptComponent;
    var FirstAidFinder = _classThis = class extends _classSuper {
        constructor() {
            super();
            this.marker = this.marker;
            this.cameraModule = this.cameraModule;
            this.gatewayBaseUrl = this.gatewayBaseUrl;
            this.mockVisionForTraining = this.mockVisionForTraining;
            this.maxPairAgeSeconds = this.maxPairAgeSeconds;
            this.maxFrameDeltaSeconds = this.maxFrameDeltaSeconds;
            this.depthModule = null;
            this.internetModule = null;
            this.cameraTexture = null;
            this.colorCamera = null;
            this.depthSession = null;
            this.colorRegistration = null;
            this.depthRegistration = null;
            this.colorHistory = [];
            this.latestPair = null;
            this.cachedPair = null;
            this.busy = false;
            this.destroyed = false;
            this.requestSerial = 0;
            this.markerLabel = null;
            this.loggedColor = false;
            this.loggedDepth = false;
            this.loggedPair = false;
        }
        __initialize() {
            super.__initialize();
            this.marker = this.marker;
            this.cameraModule = this.cameraModule;
            this.gatewayBaseUrl = this.gatewayBaseUrl;
            this.mockVisionForTraining = this.mockVisionForTraining;
            this.maxPairAgeSeconds = this.maxPairAgeSeconds;
            this.maxFrameDeltaSeconds = this.maxFrameDeltaSeconds;
            this.depthModule = null;
            this.internetModule = null;
            this.cameraTexture = null;
            this.colorCamera = null;
            this.depthSession = null;
            this.colorRegistration = null;
            this.depthRegistration = null;
            this.colorHistory = [];
            this.latestPair = null;
            this.cachedPair = null;
            this.busy = false;
            this.destroyed = false;
            this.requestSerial = 0;
            this.markerLabel = null;
            this.loggedColor = false;
            this.loggedDepth = false;
            this.loggedPair = false;
        }
        onAwake() {
            if (!this.marker) {
                // The integrated scene uses this world-root fallback. A separately
                // authored marker can still be assigned through the Inspector.
                this.marker = global.scene.createSceneObject('SC Possible Equipment Marker');
            }
            if (this.marker) {
                const label = this.marker.createComponent('Component.Text');
                this.markerLabel = label;
                label.text = '( + )';
                label.size = 52;
                label.depthTest = false;
                label.textFill.color = new vec4(0.30, 1, 0.82, 1);
                label.backgroundSettings.enabled = false;
                this.marker.enabled = false;
            }
            global.secondChanceFindEquipment = (item) => {
                void this.findItem(item);
            };
            global.secondChanceClearEquipment = () => {
                this.requestSerial++;
                if (this.marker)
                    this.marker.enabled = false;
                this.cachedPair = null;
                this.busy = false;
            };
            this.createEvent('OnStartEvent').bind(() => this.start());
            this.createEvent('OnDestroyEvent').bind(() => this.cleanup());
            this.createEvent('UpdateEvent').bind(() => {
                if (this.marker && this.marker.enabled) {
                    const camera = global.scene.getRootObject(0);
                    if (camera)
                        this.marker.getTransform().setWorldRotation(camera.getTransform().getWorldRotation());
                }
            });
        }
        start() {
            if (!this.marker) {
                print('[FirstAidFinder] Assign a world-space marker SceneObject.');
                return;
            }
            if (global.deviceInfoSystem.isEditor()) {
                this.setStatus('Device camera/depth required; test on Spectacles.');
                return;
            }
            try {
                if (!this.cameraModule)
                    throw new Error('Camera Module asset not assigned');
                // Gen 5 depth is aligned to the left color camera. Do not silently
                // substitute Default_Color on newer Specs, where it may mean right.
                const request = CameraModule.createCameraRequest();
                request.cameraId = CameraModule.CameraId.Left_Color;
                request.imageSmallerDimension = 756;
                this.cameraTexture = this.cameraModule.requestCamera(request);
                this.colorCamera = global.deviceInfoSystem.getTrackingCameraForId(CameraModule.CameraId.Left_Color);
                const provider = this.cameraTexture.control;
                this.colorRegistration = provider.onNewFrame.add((frame) => {
                    if (!this.cameraTexture || this.destroyed)
                        return;
                    if (!this.loggedColor) {
                        this.loggedColor = true;
                        print('[FirstAidFinder] Color camera frames received');
                    }
                    // copyFrame freezes RGB pixels; the live Texture changes every frame.
                    this.colorHistory.push({
                        texture: this.cameraTexture.copyFrame(),
                        timestamp: frame.timestampSeconds
                    });
                    if (this.colorHistory.length > 8)
                        this.colorHistory.shift();
                });
            }
            catch (error) {
                this.setStatus('Camera unavailable. Check camera permission.');
                print('[FirstAidFinder] Camera start failed: ' + error);
                return;
            }
            try {
                this.depthModule = require('LensStudio:DepthModule');
                // A DepthFrameSession streams depth; saveDepthFrame below is our cache
                // operation, as in Snap's Depth Cache sample, not a DepthModule method.
                this.depthSession = this.depthModule.createDepthFrameSession();
                this.depthRegistration = this.depthSession.onNewFrame.add((frame) => this.onDepthFrame(frame));
                this.depthSession.start();
                print('[FirstAidFinder] Camera and depth sessions started');
            }
            catch (error) {
                this.setStatus('Depth unavailable. Enable Experimental APIs.');
                print('[FirstAidFinder] Depth start failed: ' + error);
                return;
            }
            // SecondChanceDisplay owns the only ASR session and forwards finalized
            // "Find the ..." commands. Starting another session cancels the first.
            try {
                this.internetModule = require('LensStudio:InternetModule');
            }
            catch (error) {
                print('[FirstAidFinder] Internet unavailable: ' + error);
            }
        }
        onDepthFrame(frame) {
            if (!this.loggedDepth) {
                this.loggedDepth = true;
                print('[FirstAidFinder] Depth frames received');
            }
            if (!this.colorHistory.length || this.destroyed)
                return;
            let closest = this.colorHistory[0];
            for (const color of this.colorHistory) {
                if (Math.abs(color.timestamp - frame.timestampSeconds) <
                    Math.abs(closest.timestamp - frame.timestampSeconds))
                    closest = color;
            }
            const delta = Math.abs(closest.timestamp - frame.timestampSeconds);
            // Reject a loose pair. A stale RGB frame would put the arrow on the wrong
            // object after the wearer moves their head.
            if (delta > this.maxFrameDeltaSeconds)
                return;
            const pose = frame.toWorldTrackingOriginFromDeviceRef;
            this.latestPair = {
                color: closest,
                depth: frame.depthFrame.slice(),
                depthCamera: frame.deviceCamera,
                worldFromDevice: mat4.fromColumns(pose.column0, pose.column1, pose.column2, pose.column3),
                timestamp: frame.timestampSeconds,
                // Camera/depth timestamps describe capture, while getTime() is the
                // Lens clock. Use one clock for freshness instead of subtracting them.
                receivedAt: getTime()
            };
            if (!this.loggedPair) {
                this.loggedPair = true;
                print('[FirstAidFinder] Synchronized color/depth pair ready');
            }
        }
        saveDepthFrame() {
            const pair = this.latestPair;
            if (!pair || getTime() - pair.receivedAt > this.maxPairAgeSeconds)
                return null;
            this.cachedPair = pair;
            return pair;
        }
        async findItem(item) {
            if (this.busy || this.destroyed)
                return;
            const names = {
                tourniquet: 'tourniquet', gauze: 'gauze',
                epinephrine: 'epinephrine', 'epinephrine auto injector': 'epinephrine auto-injector',
                'epinephrine auto-injector': 'epinephrine auto-injector',
                'aed trainer': 'aed trainer'
            };
            item = names[item] || '';
            if (!item) {
                this.setStatus('Supported: tourniquet, gauze, epinephrine, AED trainer.');
                return;
            }
            const pair = this.saveDepthFrame();
            if (!pair || !this.colorCamera) {
                this.setStatus('Camera/depth not ready. Please try again.');
                return;
            }
            this.busy = true;
            const serial = ++this.requestSerial;
            this.marker.enabled = false;
            this.setStatus('Searching training view for ' + item + '...');
            try {
                const imageBase64 = await this.encodeJpeg(pair.color.texture);
                if (this.destroyed || serial !== this.requestSerial)
                    return;
                const prompt = 'Locate the ' + item +
                    ' in this medical kit. Return JSON: {"found": boolean, ' +
                    '"coordinates": [x, y]}. Coordinates are image pixels, origin ' +
                    'at the upper left. If uncertain, return found:false.';
                const result = await this.fetchVisionLLM(imageBase64, prompt, item, pair.color.texture.getWidth(), pair.color.texture.getHeight());
                if (this.destroyed || serial !== this.requestSerial)
                    return;
                if (!result.found || !result.coordinates) {
                    this.setStatus('Item not located. Ask the dispatcher or another person.');
                    return;
                }
                const world = this.pixelToWorld(pair, result.coordinates);
                if (!world) {
                    this.setStatus('Object depth uncertain. Try another view.');
                    return;
                }
                this.marker.getTransform().setWorldPosition(world);
                if (this.markerLabel)
                    this.markerLabel.text = item.toUpperCase().slice(0, 16) + '  +';
                this.marker.enabled = true;
                this.setStatus(this.mockVisionForTraining
                    ? 'SIMULATED marker for ' + item + ' — verify visually.'
                    : 'Possible ' + item + ' — verify visually.');
                print('[FirstAidFinder] Marker placed at ' + world.toString());
            }
            catch (error) {
                this.marker.enabled = false;
                this.setStatus('Image analysis unavailable.');
                print('[FirstAidFinder] Search failed: ' + error);
            }
            finally {
                // Drop every retained reference to this capture. The camera/depth ring
                // continues, but the frozen request pair must not survive model latency.
                if (serial === this.requestSerial) {
                    if (this.latestPair === pair)
                        this.latestPair = null;
                    this.cachedPair = null;
                    this.busy = false;
                }
            }
        }
        encodeJpeg(texture) {
            return new Promise((resolve, reject) => {
                Base64.encodeTextureAsync(texture, resolve, () => reject(new Error('JPEG encoding failed')), CompressionQuality.IntermediateQuality, EncodingType.Jpg);
            });
        }
        /**
         * The explicit training mock returns the center pixel without inspecting
         * the image. Normal mode sends a bounded request to our own gateway. The
         * gateway keeps the OpenAI key secret and validates item and coordinates.
         */
        async fetchVisionLLM(imageBase64, prompt, item, width, height) {
            if (!imageBase64 || !prompt)
                return { found: false };
            if (this.mockVisionForTraining) {
                print('[FirstAidFinder] SIMULATED center pixel; no object recognition.');
                return Promise.resolve({ found: true, coordinates: [width / 2, height / 2] });
            }
            if (!this.gatewayBaseUrl || !this.internetModule)
                throw new Error('Gateway unavailable');
            const url = this.gatewayBaseUrl.replace(/\/$/, '') + '/api/lens/find';
            const response = await this.internetModule.fetch(new Request(url, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ image: 'data:image/jpeg;base64,' + imageBase64,
                    item, width, height })
            }));
            if (response.status !== 200)
                throw new Error('Gateway HTTP ' + response.status);
            const result = await response.json();
            if (!result || result.found !== true || !Array.isArray(result.coordinates) ||
                result.coordinates.length !== 2)
                return { found: false };
            const x = result.coordinates[0], y = result.coordinates[1];
            if (!isFinite(x) || !isFinite(y) || x < 0 || y < 0 || x >= width || y >= height)
                return { found: false };
            return { found: true, coordinates: [x, y] };
        }
        pixelToWorld(pair, pixel) {
            const width = pair.color.texture.getWidth();
            const height = pair.color.texture.getHeight();
            const x = pixel[0], y = pixel[1];
            if (!isFinite(x) || !isFinite(y) || x < 0 || y < 0 || x >= width || y >= height)
                return null;
            // 1. The model reports pixels in the frozen RGB image. Convert to [0,1]
            // using that image's dimensions, not the display or depth resolution.
            const colorUv = new vec2(x / width, y / height);
            // 2. Both DeviceCamera methods operate in device reference space. Cast a
            // ray through the RGB pixel at any positive depth (100 cm here), then
            // project that point through the DEPTH camera. This accounts for camera
            // intrinsics, crop, and the left/depth camera offset.
            const rayPoint = this.colorCamera.unproject(colorUv, 100);
            const depthUv = pair.depthCamera.project(rayPoint);
            if (!isFinite(depthUv.x) || !isFinite(depthUv.y) || depthUv.x < 0 ||
                depthUv.y < 0 || depthUv.x >= 1 || depthUv.y >= 1)
                return null;
            const dw = Math.floor(pair.depthCamera.resolution.x);
            const dh = Math.floor(pair.depthCamera.resolution.y);
            const dx = Math.floor(depthUv.x * dw);
            const dy = Math.floor(depthUv.y * dh);
            // 3. A 3x3 median reduces isolated invalid or noisy depth pixels.
            const valid = [];
            for (let oy = -1; oy <= 1; oy++)
                for (let ox = -1; ox <= 1; ox++) {
                    const sx = dx + ox, sy = dy + oy;
                    if (sx < 0 || sy < 0 || sx >= dw || sy >= dh)
                        continue;
                    const depthCm = pair.depth[sx + sy * dw];
                    if (isFinite(depthCm) && depthCm > 10 && depthCm < 450)
                        valid.push(depthCm);
                }
            if (valid.length < 3)
                return null;
            valid.sort((a, b) => a - b);
            const depthCm = valid[Math.floor(valid.length / 2)];
            // 4. Unproject the depth pixel using its measured centimeter distance;
            // then apply the POSE CAPTURED WITH THAT DEPTH FRAME. Applying the current
            // head pose would make the marker shift when the model answer is delayed.
            const devicePoint = pair.depthCamera.unproject(depthUv, depthCm);
            const world = pair.worldFromDevice.multiplyPoint(devicePoint);
            return isFinite(world.x) && isFinite(world.y) && isFinite(world.z)
                ? world : null;
        }
        setStatus(message) {
            const callback = global.secondChanceVisionStatus;
            if (typeof callback === 'function')
                callback(message);
            print('[FirstAidFinder] ' + message);
        }
        cleanup() {
            this.destroyed = true;
            this.requestSerial++;
            if (this.marker)
                this.marker.enabled = false;
            if (global.secondChanceFindEquipment)
                global.secondChanceFindEquipment = null;
            if (global.secondChanceClearEquipment)
                global.secondChanceClearEquipment = null;
            if (this.depthSession) {
                if (this.depthRegistration)
                    this.depthSession.onNewFrame.remove(this.depthRegistration);
                this.depthSession.stop();
            }
            if (this.cameraTexture && this.colorRegistration)
                this.cameraTexture.control
                    .onNewFrame.remove(this.colorRegistration);
            this.colorHistory = [];
            this.latestPair = null;
            this.cachedPair = null;
        }
    };
    __setFunctionName(_classThis, "FirstAidFinder");
    (() => {
        const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        FirstAidFinder = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return FirstAidFinder = _classThis;
})();
exports.FirstAidFinder = FirstAidFinder;
//# sourceMappingURL=FirstAidFinder.js.map