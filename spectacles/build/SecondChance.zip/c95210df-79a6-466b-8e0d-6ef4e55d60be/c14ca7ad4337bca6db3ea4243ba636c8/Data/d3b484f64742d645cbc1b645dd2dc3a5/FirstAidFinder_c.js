﻿if (script.onAwake) {
    script.onAwake();
    return;
}
function checkUndefined(property, showIfData) {
    for (var i = 0; i < showIfData.length; i++) {
        if (showIfData[i][0] && script[showIfData[i][0]] != showIfData[i][1]) {
            return;
        }
    }
    if (script[property] == undefined) {
        throw new Error("Input " + property + " was not provided for the object " + script.getSceneObject().name);
    }
}
// @input SceneObject marker
// @input Asset.CameraModule cameraModule
// @input string gatewayBaseUrl = "http://127.0.0.1:4173"
// @input bool mockVisionForTraining
// @input bool useOwnAsr
// @input float maxPairAgeSeconds = 0.5
// @input float maxFrameDeltaSeconds = 0.07
if (!global.BaseScriptComponent) {
    function BaseScriptComponent() {}
    global.BaseScriptComponent = BaseScriptComponent;
    global.BaseScriptComponent.prototype = Object.getPrototypeOf(script);
    global.BaseScriptComponent.prototype.__initialize = function () {};
    global.BaseScriptComponent.getTypeName = function () {
        throw new Error("Cannot get type name from the class, not decorated with @component");
    };
}
var Module = require("../../../Modules/Src/Assets/FirstAidFinder");
Object.setPrototypeOf(script, Module.FirstAidFinder.prototype);
script.__initialize();
let awakeEvent = script.createEvent("OnAwakeEvent");
awakeEvent.bind(() => {
    checkUndefined("marker", []);
    checkUndefined("cameraModule", []);
    checkUndefined("gatewayBaseUrl", []);
    checkUndefined("mockVisionForTraining", []);
    checkUndefined("useOwnAsr", []);
    checkUndefined("maxPairAgeSeconds", []);
    checkUndefined("maxFrameDeltaSeconds", []);
    if (script.onAwake) {
       script.onAwake();
    }
});
